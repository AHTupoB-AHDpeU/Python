from django.forms import ModelForm
from .models import Comment
from django import forms


class CommentForm(ModelForm):
    class Meta:
        model = Comment
        fields = ["text", "image"]

    def __init__(self, *args, **kwargs):
        super(CommentForm, self).__init__(*args, **kwargs)

        self.fields["text"].help_text = ""
        self.fields["text"].label = ""
        self.fields["text"].widget = forms.Textarea(
            attrs={
                "placeholder": "Текст комментария",
                "rows": 1,
                "class": "from-control",
            }
        )
