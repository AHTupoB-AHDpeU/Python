from datetime import datetime

from django.shortcuts import render, redirect
from .models import Post, ImageModel, Comment
from .forms import CommentForm
# странички*


def index(request):
    posts = Post.objects.all().order_by('-id')[:3]  # filter, get
    title = "Главная страница"
    image_model = ImageModel.objects.get(pk=4)
    return render(request, 'my_blog/blog_list.html', {"posts": posts, "title": title, "image_model": image_model})


def detail(request, pk):
    posts = Post.objects.all()
    post = posts.get(pk=pk)
    title = post.title

    count = str(request.GET.get("post_count"))
    comments = Comment.objects.filter(post=post).order_by("-date_published")

    if count == "next":
        if post.id == posts.last().id:
            return redirect("post:detail", pk=posts.first().id)
        next_post = posts.filter(id__gt=post.id).first()
        return redirect("post:detail", pk=next_post.id)

    if count == "prev":
        if post.id == posts.first().id:
            return redirect("post:detail", pk=posts.last().id)
        prev_post = posts.filter(id__lt=post.id).last()
        return redirect("post:detail", pk=prev_post.id)

    context = {
        "post": post,
        "title": title,
        "comments": comments
    }

    if request.method == "POST":
        form = CommentForm(request.POST, request.FILES)  # request.FILES
        if form.is_valid():
            new_comm = form.save(commit=False)
            new_comm.author = request.user
            new_comm.date_published = datetime.now()
            new_comm.post = post
            new_comm.save()
            return redirect("post:detail", pk=pk)

    else:
        form = CommentForm()

    context["form"] = form

    return render(request, 'my_blog/post_detail.html', context)


def news(request):
    title = "Новостная лента"

    sorting = request.GET.get("сортировка", "new")
    if sorting == "new":
        sorting_now = "-id"
    else:
        sorting_now = "id"

    posts_news = Post.objects.all().order_by(sorting_now)

    search = request.GET.get("search")
    if search:
        posts_news = posts_news.filter(title__icontains=search)

    return render(request, 'my_blog/news.html', {"posts_news": posts_news, "title": title, "sorting": sorting})


def contact(request):
    title = "Контакты"
    image_model_contact1 = ImageModel.objects.get(pk=5)
    image_model_contact2 = ImageModel.objects.get(pk=6)
    image_model_contact3 = ImageModel.objects.get(pk=7)
    return render(request, 'my_blog/contact.html', {"image_model_contact1": image_model_contact1, "image_model_contact2": image_model_contact2, "image_model_contact3": image_model_contact3, "title": title})
