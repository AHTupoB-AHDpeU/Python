from django.shortcuts import render
from .models import Post, ImageModel
# странички*


def index(request):
    posts = Post.objects.all().order_by('-id')[:3]  # filter, get
    title = "Главная страница"
    image_model = ImageModel.objects.get(pk=4)
    return render(request, 'my_blog/blog_list.html', {"posts": posts, "title": title, "image_model": image_model})


def detail(request, pk):
    post = Post.objects.get(pk=pk)
    title = post.title
    return render(request, 'my_blog/post_detail.html', {"post": post, "title": title})


def news(request):
    title = "Новостная лента"
    posts_news = Post.objects.all().order_by('-id')
    return render(request, 'my_blog/news.html', {"posts_news": posts_news, "title": title})


def contact(request):
    title = "Контакты"
    image_model = ImageModel.objects.get(pk=4)
    image_model_contact1 = ImageModel.objects.get(pk=5)
    image_model_contact2 = ImageModel.objects.get(pk=6)
    image_model_contact3 = ImageModel.objects.get(pk=7)
    return render(request, 'my_blog/contact.html', {"image_model": image_model, "image_model_contact1": image_model_contact1, "image_model_contact2": image_model_contact2, "image_model_contact3": image_model_contact3, "title": title})


def registration(request):
    title = "Регистрация"
    return render(request, 'my_blog/registration.html', {"title": title})


def login(request):
    title = "Авторизация"
    return render(request, 'my_blog/login.html', {"title": title})
