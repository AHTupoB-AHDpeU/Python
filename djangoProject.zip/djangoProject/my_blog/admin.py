from django.contrib import admin

from .models import Post
from .models import ImageModel

admin.site.register(Post)
admin.site.register(ImageModel)
