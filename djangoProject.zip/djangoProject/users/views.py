from datetime import datetime

from django.contrib.auth.views import LoginView, LogoutView
from django.shortcuts import render, redirect
from .forms import AuthUserForm, RegUserForm
from django.contrib.auth import login


def register(request):
    register_form = RegUserForm(request.POST)
    if request.method == "POST":
        if register_form.is_valid():
            r_form = register_form.save(commit=False)  # Пользователь, атрибуты
            r_form.is_active = True
            r_form.is_staff = False
            r_form.is_superuser = False
            r_form.date_joined = datetime.now()
            r_form.last_login = datetime.now()
            r_form.save()

            r_form.backend = 'django.contrib.auth.backends.ModelBackend'
            login(request, r_form)
            return redirect('post:index')
    else:
        register_form = RegUserForm()
    return render(request, "users/registration.html", {"register_form": register_form})


class login_class(LoginView):
    fields = ["username", "password"]
    template_name = 'users/login.html'
    form_class = AuthUserForm


class logout(LogoutView):
    template_name = 'logout.html'
